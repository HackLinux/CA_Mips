README

Group:
Nick Robinson
Matt McDonald

TopLevel:
mips_tb.v 

Included Files:
add32.v
alu.v
control.v
matrix.hexdump
memory.v
mips_cpu.v
mips_tb.v
mux.v
regbank.v
//NEW IN PART 2
mips_cpu_adv.v - NOTE - we made a new module instead of overwriting old
hazard_unit.v
forward_unit.v
branch_control.v
IF_ID_Reg.v
ID_EX_Reg.v
EX_MEM_Reg.v
MEM_WB_Reg.v
mux3.v

Supporting Files:
matrix.s
/Altera
/Modelsim
project_specification.pdf
